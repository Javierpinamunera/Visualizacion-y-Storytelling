Dashboard del Servicio de Salud del Principado de Asturias


1. Estructura del Dashboard

El dashboard está compuesto por dos secciones principales, diseñadas para ofrecer una visión completa y accesible de los datos médicos y operativos del Servicio de Salud del Principado de Asturias.

El objetivo principal es analizar y visualizar información clave sobre la atención hospitalaria, mostrando tanto métricas generales como detalles específicos por paciente, optimizando así la toma de decisiones y la gestión sanitaria.

1.1 Pestaña de Datos Generales

En esta primera página se presenta una visión global del flujo asistencial de los pacientes, con foco en los tiempos, tipos de triaje y decisiones médicas.

Incluye:

- Hora de entrada, hora de triaje y hora de salida.
- Tipo de triaje asignado a cada paciente.
- Propuesta médica: si el paciente debe ser ingresado o no.
- Estado final del paciente: ingresado o dado de alta.
- Distribución por edificio, unidad y tipo de atención.
- Visualizaciones generales con gráficos de barras, tablas dinámicas y filtros interactivos.

Objetivo: ofrecer una visión clara del funcionamiento general del servicio sanitario y del flujo de atención a los pacientes.

1.2 Pestaña de Consulta Específica

Esta segunda sección permite realizar consultas detalladas por paciente, accediendo a toda la información relevante registrada.

Incluye:

- Filtro dinámico por ID de paciente
- Tablas detalladas con datos individuales.
- Visualizaciones específicas adaptadas al caso seleccionado.

Objetivo: permitir un análisis más profundo y personalizado de cada caso, facilitando la trazabilidad y el seguimiento de la atención médica.

2. Tecnologías y Herramientas Utilizadas

- Looker Studio (Google Data Studio) – para la creación del dashboard y visualización de datos.
- Google Sheets / CSV – como fuente de datos principal.
- Conectores de Looker Studio – para la importación y vinculación de datos.
- Funciones de agregación y filtrado – para la creación de métricas y visualizaciones interactivas.

3. Resultados del Proyecto

- Dashboard dinámico e intuitivo con navegación fluida entre pestañas.
- Visualización clara de los procesos de atención médica desde la entrada hasta el alta o ingreso.
- Herramienta útil para el análisis operativo y la optimización de recursos hospitalarios.
- Demostración práctica del manejo de Looker Studio y sus capacidades analíticas.
- Diseño funcional y limpio orientado a la toma de decisiones basada en datos.

4. Autor

Javier Piña Munera