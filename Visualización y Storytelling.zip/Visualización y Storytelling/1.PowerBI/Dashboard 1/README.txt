Dashboard de recursos Humanos

1.Estructura del Dashboard

El dashboard se compone de tres páginas principales, cada una enfocada en un aspecto clave del análisis:

1.1 Análisis de Empleados y Evaluación del Equipo

Esta primera hoja presenta una visión general de los empleados y su distribución dentro de la organización.
Incluye:

- KPIs generales del equipo.
- Distribución de empleados por grupo de edad, rango salarial y nivel de evaluación.
- Gráficos de composición por departamento.
- Mapa geográfico donde se visualiza la concentración de empleados por ubicación.

Objetivo: entender la estructura del equipo y cómo se distribuyen los empleados en función de edad, salario y desempeño.

1.2 Análisis de Sueldos

En esta segunda hoja se profundiza en la estructura salarial de la organización.
Incluye:

- KPIs generales de sueldos.
- Gráfico de sueldo promedio por edad.
- Tabla detallada con nombre del empleado, departamento, posición, estado, género y sueldo promedio.
- Promedio salarial por departamento.
- Mapa interactivo con la distribución de los sueldos más altos por región.

Objetivo: identificar patrones salariales, posibles brechas de género o diferencias entre departamentos.

1.3 Evaluación del Desempeño

La tercera hoja está enfocada en el análisis de la evaluación de desempeño del personal.
Incluye:

- KPIs generales de evaluación.
- Evaluación promedio por jefe y por género.
- Tabla completa con empleado, departamento, posición, estado, género y evaluación promedio.
- Evaluación promedio por departamento.
- Mapa interactivo que muestra las distintas evaluaciones promedio por estado dentro de Estados Unidos.

Objetivo: analizar el rendimiento del personal desde diferentes perspectivas y detectar oportunidades de mejora.

2.Tecnologías y Herramientas Utilizadas

- Power BI Desktop – para modelado, diseño de informes y visualización.
- Power Query – para la conexión, limpieza y transformación de datos.
- DAX – para la creación de métricas y KPIs personalizados.
- Excel / CSV / SQL – como fuentes de datos principales.

3.Resultados del Proyecto

- Dashboard completamente interactivo y dinámico.
- Visualización clara de la estructura organizacional, salarios y desempeño.
- Identificación de patrones clave en los datos de empleados.
- Herramienta efectiva para la toma de decisiones estratégicas en RRHH.

4.Autor

Javier Piña Munera