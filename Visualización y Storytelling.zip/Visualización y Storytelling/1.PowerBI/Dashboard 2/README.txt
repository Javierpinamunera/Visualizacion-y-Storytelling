Dashboard de Análisis de Datos – Renfe

1. Estructura del Dashboard

El dashboard se compone de cuatro páginas principales, cada una con un propósito analítico distinto y conectadas entre sí mediante una página de resumen central que actúa como núcleo de navegación y filtrado global.

1.1 Portada

La primera hoja funciona como pantalla de inicio o portada del informe.
Incluye una presentación visual del proyecto, la identidad gráfica de Renfe y enlaces interactivos que permiten acceder directamente al resto de las hojas del dashboard.

Objetivo: ofrecer una navegación clara, intuitiva y profesional dentro del informe.

1.2 Hoja de Resumen

Esta sección actúa como centro de control del dashboard, concentrando la información más relevante del conjunto de datos.

Incluye:

- KPIs generales (viajes, precios promedio, ingresos, etc.).
- Filtros globales que permiten modificar las visualizaciones de todas las hojas del informe.
- Diseño optimizado para facilitar el análisis transversal de los datos.

Objetivo: centralizar los filtros para una experiencia de usuario más limpia y coherente, y ofrecer una visión global del desempeño del servicio.

1.3 Análisis de Viajes

En esta hoja se profundiza en el comportamiento de los viajes realizados.

Incluye:

- Viajes clasificados por tarifa, semana y destino.
- Gráficos dinámicos que muestran tendencias y comparativas.
- Indicadores visuales para detectar patrones de demanda.

Objetivo: analizar la evolución de los viajes según diferentes variables y detectar los destinos y tarifas más relevantes.

1.4 Análisis de Precios

Aquí se detalla la estructura y comportamiento de los precios de los billetes.

Incluye:

- Precio promedio, mediano, más alto y más bajo.
- Gráficos comparativos de precios por semana o destino.
- Visualizaciones que permiten identificar variaciones estacionales o por tipo de servicio.

Objetivo: comprender las fluctuaciones de precios y posibles patrones de optimización tarifaria.

1.5 Hoja de Tablas (Dataset)

Esta última hoja recoge las tablas originales del conjunto de datos utilizado, ofreciendo transparencia y detalle sobre la información base.
Permite revisar de forma estructurada los campos, cálculos y transformaciones aplicadas.

Objetivo: ofrecer una referencia directa a la fuente de datos y facilitar su comprensión.

2. Tecnologías y Herramientas Utilizadas

- Power BI Desktop – para modelado, visualización y diseño del informe.
- Power Query – para la limpieza, transformación y preparación de los datos.
- DAX – para la creación de cálculos, medidas y KPIs personalizados.
- Excel / CSV – como fuente principal de datos.

3. Resultados del Proyecto

- Dashboard completamente interactivo y navegable mediante enlaces internos.
- Sistema de filtros centralizados que afectan a todas las hojas del informe.
- Visualización clara y organizada de los viajes, tarifas y precios.
- Integración de identidad visual corporativa (Renfe) mediante íconos y diseño temático.
- Herramienta adaptable para el análisis de rendimiento y precios en servicios de transporte.

4. Autor

Javier Piña Munera